from func import *

# module 3: Create label for all user
# requiments: save output of: MATCH p=(:User)-[:MemberOf]->() RETURN p to rela_users.json


def user_mark(groups, group_dict, group_label_data):
    flag = 2
    for group in groups:
        name = find_group(group, group_dict)
        if group_label_data[name] < flag:
            flag = group_label_data[name]
    return flag

def create_user_mark():
    rela_user = 'rela_users.json'
    rela_user_data = read_json(rela_user)
    group_label = 'group_label.json'
    group_label_data = read_json(group_label)

    nodes, edges = extract_json(rela_user_data)
    relations = extract_edges(edges)

    group_dict = extract_node_group(nodes)
    user_dict = extract_node_user(nodes)

    user_labels = {}
    for key, value in relations.items():
        flag = user_mark(value, group_dict, group_label_data)
        user_labels[find_user(int(key), user_dict)] = flag
    write_json(user_labels, 'user_label.json')
    return user_labels
