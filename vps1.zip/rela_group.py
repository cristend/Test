from func import *

# module 1: Create label for group have relation MemberOf
# requiments: save output of: MATCH p=(:Group)-[:MemberOf]->(:Group) RETURN p to rela_group.json
group_marks = {

}

Dangerous = [
    'account operators',
    'administrators',
    'backup operators',
    'cert publishers',
    'domain admins',
    'domain controllers',
    'enterprise admins',
    'enterprise key admins',
    'group policy creator owners',
    'key admins',
    'print operators',
    'schema admins',
    'replicator',
    'server operators',
    'hyper-v administrators',
    'storage replica administrators'
]

Priv = [
    'access control assistance operators',
    'allowed rodc password replication',
    'certificate service dcom access',
    'cloneable domain controllers',
    'cryptographic operators',
    'denied rodc password replication',
    'device owners',
    'dhcp administrators',
    'dhcp users',
    'distributed com users',
    'dnsupdateproxy',
    'dnsadmins',
    'enterprise read-only domain controllers',
    'event log readers',
    'group policy creator owners',
    'incoming forest trust builders',
    'network configuration operators',
    'performance log users',
    'performance monitor users',
    'ras and ias servers',
    'rds endpoint servers',
    'rds management servers',
    'rds remote access servers',
    'read-only domain controllers',
    'remote desktop users',
    'remote management users',
    'terminal server license servers',
    'windows authorization access',
    'winrmremotewmiusers_'
]
Normal = [
    'domain computers',
    'domain guests',
    'domain users',
    'guests',
    'iis_iusrs',
    'pre–windows 2000 compatible access',
    'protected users',
    'system managed accounts'
]


def get_flag(name):
    name = name.lower()
    if name in Normal:
        return 2
    if name in Priv:
        return 1
    if name in Dangerous:
        return 0
    return 2


def find_parent(id, relations):
    if int(id) in relations:
        return relations[int(id)]


def find_name(id, spotlight):
    if str(id) in spotlight:
        return spotlight[str(id)][0].rsplit('@', 1)[0]
    else:
        return None


def find_root_parent(id, spotlight, relations, tree={}):
    current_flag, current_name = group_mark(id, spotlight)
    parents = find_parent(id, relations)
    if parents:
        tmp_flag = current_flag
        for parent in parents:
            tree[parent] = {}
            grand, flag = find_root_parent(parent, spotlight, relations, tree[parent])
            tree[parent] = grand
            if grand is not None:
                flag, name = group_mark(parent,spotlight)
                if name not in group_marks:
                    group_marks[name] = flag
                if flag < current_flag:
                    tmp_flag = flag
        return tree, tmp_flag
    else:
        # leaf
        if current_name not in group_marks:
            group_marks[current_name] = current_flag
        return None, current_flag


def group_mark(id, spotlight):
    group_name = find_name(id, spotlight)
    flag = get_flag(group_name)
    return flag, group_name

def create_rela_group_mark():
    filename = 'rela_group.json'
    data = read_json(filename)
    nodes, edges, spotlight = extract_json(data)
    relations = extract_edges(edges)

    trees = {}
    for key, value in spotlight.items():
        name = find_name(key, spotlight)
        sub_tree, flag = find_root_parent(key, spotlight, relations, {})
        trees[key] = sub_tree
        if name not in group_marks:
            group_marks[name] = flag

    write_json(group_marks, 'rela_group_label.json')
