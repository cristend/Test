from rela_group import *
from single_group import *
from user import *
from func import *

create_rela_group_mark()
group_labels = create_group_mark()
user_labels = create_user_mark()
print(len(group_labels))

blood_hound_edges = [
    'adminTo'
]

for edge in blood_hound_edges:
    print(f"[+] Checking {edge}")
    edge_json = edge + '.json'
    edge_json_data = read_json(edge_json)
    nodes, edges, spotlight = extract_json(edge_json_data)
    relations = extract_edges(edges)
    
    group_dict = extract_node_group(nodes)
    user_dict = extract_node_user(nodes)
    computer_dict = extract_node_computer(nodes)
    
    output = []
    for source_id, target_list in relations.items():
        mark, name = verify_relations(source_id, computer_dict, user_dict, group_dict, group_labels, user_labels)
        targets = ""
        for target in target_list:
            target_name = ""
            if target in group_dict:
                target_name = find_group(target, group_dict)
            if target in user_dict:
                target_name = find_user(target, user_dict)
            if target in computer_dict:
                target_name = find_computer(target, computer_dict)
            targets = targets + target_name + '\n'
        tmp = build_result(name, edge, targets, mark)
        output.append(tmp)
    # print(f"[+] {edge} done! Output file save to {edge+'.csv'}")
    write_csv(output, edge+'.csv')
    