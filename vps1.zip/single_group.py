from func import *

# module 2: Create label for all group
# requiments: save output of: MATCH p=(:User)-[:MemberOf]->() RETURN p to rela_users.json


def extract_group(nodes):
    labels = []
    for node in nodes:
        if node['type'].lower() == "group":
            label = node['label']
            labels.append(label)
    return labels


def remark_group(rela_labels, normal_labels):
    for label in normal_labels:
        label = label.rsplit('@', 1)[0]
        if label not in rela_labels:
            rela_labels[label] = 2
    return rela_labels

def create_group_mark():
    rela_user = 'rela_users.json'
    rela_user_data = read_json(rela_user)
    nodes, edges = extract_json(rela_user_data)

    rela_group = 'rela_group_label.json'
    rela_group_data = read_json(rela_group)

    group_labels = remark_group(rela_group_data, extract_group(nodes))
    write_json(group_labels, 'group_label.json')
    return group_labels
