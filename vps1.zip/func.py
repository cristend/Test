import json
import csv


def read_json(filename):
    with open(filename, 'r') as f:
        data = f.read()
    try:
        data_json = json.loads(data)
    except Exception as e:
        raise e
    return data_json


def extract_json(data):
    if 'spotlight' in data:
        return data['nodes'], data['edges'], data['spotlight']
    return data['nodes'], data['edges']


def extract_edges(edges):
    relations = {}
    for edge in edges:
        if edge['source'] not in relations:
            relations[edge['source']] = []
            relations[edge['source']].append(edge['target'])
        else:
            relations[edge['source']].append(edge['target'])
    return relations


def extract_node_group(nodes):
    result = {}
    for node in nodes:
        if node['type'].lower() == "group":
            label = node['label'].rsplit('@', 1)[0]
            result[node['id']] = label
    return result


def extract_node_user(nodes):
    result = {}
    for node in nodes:
        if node['type'].lower() == "user":
            label = node['label'].rsplit('@', 1)[0]
            result[node['id']] = label
    return result


def extract_node_computer(nodes):
    result = {}
    for node in nodes:
        if node['type'].lower() == "computer":
            label = node['label'].rsplit('@', 1)[0]
            result[node['id']] = label
    return result


def find_group(id, group_dict):
    return group_dict[id]


def find_user(id, user_dict):
    return user_dict[id]


def find_computer(id, computer_dict):
    return computer_dict[id]


def verify_user(source_id, user_dict, user_labels):
    name = find_user(source_id, user_dict)
    flag = user_labels[name]
    if flag == 2:
        return "Vuls", name
    if flag == 1:
        return "Risk", name
    if flag == 0:
        return "Normal", name


def verify_group(source_id, group_dict, group_labels):
    name = find_group(source_id, group_dict)
    try:
        flag = group_labels[name]
    except Exception as test:
        import pdb
        pdb.set_trace()
    if flag == 2:
        return "Vuls", name
    if flag == 1:
        return "Risk", name
    if flag == 0:
        return "Normal", name


def verify_computer(source_id, computer_dict):
    name = find_computer(source_id, computer_dict)
    return "Risk", name


def check_type(source_id, computer_dict, user_dict):
    if source_id in computer_dict:
        return 1
    if source_id in user_dict:
        return 2
    return 0


def verify_relations(source_id, computer_dict, user_dict, group_dict, group_labels, user_labels):
    mark = ""
    name = ""
    acount_type = check_type(source_id, computer_dict, user_dict)
    if acount_type == 1:
        mark, name = verify_computer(source_id, computer_dict)
    if acount_type == 2:
        mark, name = verify_user(source_id, user_dict, user_labels)
    if acount_type == 0:
        mark, name = verify_group(source_id, group_dict, group_labels)
    return mark, name


def build_result(source, relation, target, mark):
    # return source + ", " + relation + ", " + target + ", " + mark + '\n'
    return [source, relation, target, mark]


def write_json(var, filename):
    with open(filename, 'w') as f:
        f.write(json.dumps(var))
        f.close()


def write_file(var, filename):
    with open(filename, 'w') as f:
        for item in var:
            print(item)
            f.write(item)
        f.close()


def write_csv(records, csv_file_name):
    try:
        with open(csv_file_name, mode='w', newline='') as file:
            writer = csv.writer(file)
            for record in records:
                writer.writerow(record)
        print(f"Records have been written to {csv_file_name}")
    except Exception as e:
        print(f"An error occurred: {e}")
